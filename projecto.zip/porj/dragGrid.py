import flet as ft

def main(page: ft.Page):

    page.title = "Fuchi"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 0
    fieldImage = ft.Image(src="soccer-field.jpg", fit=ft.ImageFit.COVER, expand=True, width=page.width+170)

    def drag_accept(e: ft.DragTargetAcceptEvent):
        src = page.get_control(e.src_id)
        e.control.content.bgcolor = src.content.bgcolor
        e.control.content.content = ft.Image(src=src.content.content.src)
        e.control.content.border = None
        e.control.content.opacity = 1
        if src.content.content.src == "Empty.png":
            e.control.content.opacity = 0.5
        e.control.update()

    targets = ft.GridView(
        expand=True,
        runs_count=5,
        max_extent=50,
        child_aspect_ratio=1,
        spacing=5,
        run_spacing=5,
    )

    field = ft.Stack(controls=[fieldImage,targets])

    for i in range(0, 216):
        targets.controls.append(
            ft.DragTarget(
                    group="color",
                    content=ft.Container(
                        width=50,
                        height=50,
                        bgcolor=ft.colors.BLUE_GREY_100,
                        border_radius=5,
                        opacity=0.5
                    ),
                    on_accept=drag_accept,

                )
        )
    cono = ft.Draggable(
                            group="color",
                            content=ft.Container(
                                width=50,
                                height=50,
                                bgcolor=ft.colors.CYAN,
                                border_radius=5,
                                content= ft.Image(
                                    src=f"1068623.png",
                                    width=50,
                                    height=50,
                                    fit=ft.ImageFit.CONTAIN,
                                ),
                            ),

                            content_feedback=ft.Container(
                                width=20,
                                height=20,
                                bgcolor=ft.colors.CYAN,
                                border_radius=3,
                                content= ft.Image(
                                    src=f"1068623.png",
                                    width=20,
                                    height=20,
                                    fit=ft.ImageFit.CONTAIN,
                                ),
                            )
                            )
    
    jugador = ft.Draggable(
                            group="color",
                            content=ft.Container(
                                width=50,
                                height=50,
                                bgcolor=ft.colors.GREEN,
                                border_radius=5,
                                content= ft.Image(
                                    src=f"Person_icon_BLACK-01.svg.png",
                                    width=50,
                                    height=50,
                                    fit=ft.ImageFit.CONTAIN,
                                ),
                            ),
                            content_feedback=ft.Container(
                                width=20,
                                height=20,
                                bgcolor=ft.colors.GREEN,
                                border_radius=3,
                                content= ft.Image(
                                    src=f"Person_icon_BLACK-01.svg.png",
                                    width=20,
                                    height=20,
                                    fit=ft.ImageFit.CONTAIN,
                                ),
                            )
                            )
    bola = ft.Draggable(
                            group="color",
                            content=ft.Container(
                                width=50,
                                height=50,
                                bgcolor=ft.colors.RED,
                                border_radius=5,
                                content= ft.Image(
                                    src=f"53283.png",
                                    width=50,
                                    height=50,
                                    fit=ft.ImageFit.CONTAIN,
                                ),
                            ),
                            content_feedback=ft.Container(
                                width=20,
                                height=20,
                                bgcolor=ft.colors.RED,
                                border_radius=3,
                                content= ft.Image(
                                    src=f"53283.png",
                                    width=20,
                                    height=20,
                                    fit=ft.ImageFit.CONTAIN,
                                ),
                            )
                            )
    
    clear = ft.Draggable(
                            group="color",
                            content=ft.Container(
                                width=50,
                                height=50,
                                bgcolor=ft.colors.BLUE_GREY_100,
                                border_radius=5,
                                opacity= 0.5,
                                content= ft.Image(
                                    src=f"Empty.png",
                                    width=20,
                                    height=20,
                                    fit=ft.ImageFit.CONTAIN,
                                )
                            ),
                            content_feedback=ft.Container(
                                width=20,
                                height=20,
                                bgcolor=ft.colors.BLUE_GREY_100,
                                border_radius=3,
                                content= ft.Image(
                                    src=f"Empty.png",
                                    width=20,
                                    height=20,
                                    fit=ft.ImageFit.CONTAIN,
                                )
                            )
                            )
    objectsRow = ft.Row(controls=[cono, jugador, bola, clear])
    finalColumn = ft.Column([field, objectsRow], scroll=ft.ScrollMode.AUTO)
    page.window_width = 1100
    page.window_height = 835
    page.window_resizable = True
    page.add(finalColumn)

ft.app(target=main)